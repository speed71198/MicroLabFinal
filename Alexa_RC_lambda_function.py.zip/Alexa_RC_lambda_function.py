#
#  Copyright 2017-2018 NXP
#  All rights reserved.
#
#  SPDX-License-Identifier: BSD-3-Clause

import boto3  # http messaging
import json   # json text builder/reader
import time

clientIOT = boto3.client('iot-data', region_name='us-east-1')

NXP_module_name = 'myNXPthing'

# --------------- Helpers that build all of the responses ----------------------

def build_speechlet_response(response_message, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': response_message
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    } 
    

def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }

# ---------------- Updating and reading Device's Shadow ----------------

def update_shadow(device, mypayload):
    clientIOT.update_thing_shadow(
        thingName = device,
        payload = mypayload
        )
    return()

def read_from_shadow(device):
    return(clientIOT.get_thing_shadow(thingName = device))

# ----------------- Functions ------------

def send_LED_message(session_attributes, session):
    
    redLedIdx  = 1
    greenLedIdx= 2
    blueLedIdx = 4
    
    action = session_attributes['action']
    ledIndex = session_attributes['LEDselection']
    addressed_device = NXP_module_name
    should_end_session = False
    
    shadow = read_from_shadow(addressed_device) #Read current status
    streamingBody = shadow["payload"]
    jsonState = json.loads(streamingBody.read())
    state_of_LED = jsonState['state']['reported']['LEDstate']
    desired_state = state_of_LED
    
    if ledIndex == 'red':
        if action == 'on':
            desired_state |= redLedIdx
        elif action == 'off':
            desired_state &= ~redLedIdx
        elif action == 'toggle':
            desired_state ^= redLedIdx
    elif ledIndex == 'green':
        if action == 'on':
            desired_state |= greenLedIdx
        elif action == 'off':
            desired_state &= ~greenLedIdx
        elif action == 'toggle':
            desired_state ^= greenLedIdx
    elif ledIndex == 'blue':
        if action == 'on':
            desired_state |= blueLedIdx
        elif action == 'off':
            desired_state &= ~blueLedIdx
        elif action == 'toggle':
            desired_state ^= blueLedIdx
    else: #'all' or no selection
        if action == 'on':
            desired_state = (redLedIdx | greenLedIdx | blueLedIdx)
        elif action == 'off':
            desired_state = 0
        elif action == 'toggle':
            desired_state ^= (redLedIdx | greenLedIdx | blueLedIdx)

    stato = {"state" : { "desired" : { "LEDstate": desired_state }}} #generate json
    mypayload = json.dumps(stato)
    update_shadow(addressed_device, mypayload)
    
    time.sleep(1.5)
    
    shadow = read_from_shadow(addressed_device)                   #read LED state after sleeping 1 sec
    streamingBody = shadow["payload"]
    jsonState = json.loads(streamingBody.read())
    state_of_LED = jsonState['state']['reported']['LEDstate']
    
    if state_of_LED == 0:
        return_message = 'all LEDs are off'
    elif state_of_LED == redLedIdx:
        return_message = 'the red LED is on'
    elif state_of_LED == greenLedIdx:
        return_message = 'the green LED is on'
    elif state_of_LED == blueLedIdx:
        return_message = 'the blue LED is on'
    elif state_of_LED == (redLedIdx | greenLedIdx | blueLedIdx):
        return_message = 'all LEDs are on'
    else:
        return_message = 'multiple LEDs are on'

    answer_for_alexa = build_speechlet_response(return_message, None, should_end_session)
    return(build_response(session_attributes, answer_for_alexa))
    
# ------------------------- EVENTS --------------------------

# this is called when user wants to interact with module's LED 
def manage_LED_request(request, session):
    
    # get desired LED state (on | off)
    action = request['intent']['slots']['LEDMessage']['value']
    try:
        LEDselection = request['intent']['slots']['LED_ID']['value']
    except:
        LEDselection = 'all'
    session_attributes_init = {"request": request['intent']['name'], "action": action, "LEDselection":LEDselection}
    session_attributes = session_attributes_init
    return(send_LED_message(session_attributes, session))

# -- end of function

# this is called when user wants to update Accelerometer reading from thing 
def manage_ACCEL_request(request, session):
    
    should_end_session = False
    session_attributes = None
    #REQUEST TO BOARD
    stato = {"state" : { "desired" : { "LEDstate": None, "accelUpdate":1 }, }} #generate json
    mypayload = json.dumps(stato)
    update_shadow(NXP_module_name, mypayload)
    
    return_message = 'The accelerometer data was updated'
    
    answer_for_alexa = build_speechlet_response(return_message, None, should_end_session)
    return(build_response(session_attributes, answer_for_alexa))

# -- end of function

# ------------------------- MAIN ----------------------------

def lambda_handler(event, context):
    
    # request_type comes from Alexa (two possible cases, see below)
    request_type = event['request']['intent']['name'] # could be "LEDIntent" or "AccelIntent"
    
    # case 1: user wants to interact with module's LED
    if request_type == 'LEDIntent':
        return(manage_LED_request(event['request'], event['session']))
    # case 2: user wants to interact with module's accelerometer
    if request_type == 'ACCELIntent':
        return(manage_ACCEL_request(event['request'], event['session']))
